import { useCallback, useEffect, useRef, useState } from 'react'

const DEFAULT_ANGLES = { pitch: 0, roll: 0 }

function parseSerialLine(line) {
  const trimmed = line.trim()
  if (!trimmed) return null

  try {
    const json = JSON.parse(trimmed)
    if (typeof json.pitch === 'number' && typeof json.roll === 'number') {
      return { pitch: json.pitch, roll: json.roll }
    }
  } catch {
    // fall through to text parsers
  }

  const labeled = trimmed.match(/p(?:itch)?\s*[:=]\s*(-?\d+(?:\.\d+)?).*r(?:oll)?\s*[:=]\s*(-?\d+(?:\.\d+)?)/i)
  if (labeled) {
    return { pitch: Number(labeled[1]), roll: Number(labeled[2]) }
  }

  const csv = trimmed.split(/[,\s]+/).map(Number).filter((n) => !Number.isNaN(n))
  if (csv.length >= 2) {
    return { pitch: csv[0], roll: csv[1] }
  }

  return null
}

export function useSensorData() {
  const [mode, setMode] = useState('simulate')
  const [autoSimulate, setAutoSimulate] = useState(false)
  const [angles, setAngles] = useState(DEFAULT_ANGLES)
  const [connected, setConnected] = useState(false)
  const [status, setStatus] = useState('Ready — adjust sliders or enable idle motion')
  const [sampleCount, setSampleCount] = useState(0)
  const [serialOutput, setSerialOutput] = useState('')
  const [isRecording, setIsRecording] = useState(false)
  const [recordedArm, setRecordedArm] = useState(null)
  const [recordedLeg, setRecordedLeg] = useState(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [playbackFrame, setPlaybackFrame] = useState(0)
  const [recordingDuration, setRecordingDuration] = useState(5)
  const [previewMode, setPreviewMode] = useState('arm')
  const [isPlayingTogether, setIsPlayingTogether] = useState(false)

  const portRef = useRef(null)
  const readerRef = useRef(null)
  const abortRef = useRef(null)
  const lineBufferRef = useRef('')
  const recordingRef = useRef([])
  const playbackIntervalRef = useRef(null)
  const recordingTimeoutRef = useRef(null)

  const disconnectSerial = useCallback(async () => {
    abortRef.current?.abort()
    abortRef.current = null

    if (readerRef.current) {
      try {
        await readerRef.current.cancel()
      } catch {
        // reader may already be released
      }
      readerRef.current = null
    }

    if (portRef.current) {
      try {
        await portRef.current.close()
      } catch {
        // port may already be closed
      }
      portRef.current = null
    }

    setConnected(false)
    setStatus('Serial disconnected')
  }, [])

  const connectSerial = useCallback(async () => {
    if (!('serial' in navigator)) {
      setStatus('Web Serial not supported in this browser')
      return
    }

    try {
      await disconnectSerial()

      const port = await navigator.serial.requestPort()
      await port.open({ baudRate: 115200 })
      portRef.current = port

      const abortController = new AbortController()
      abortRef.current = abortController

      const reader = port.readable.getReader()
      readerRef.current = reader
      const decoder = new TextDecoder()

      setMode('serial')
      setConnected(true)
      setStatus('Streaming from ESP32')

      ;(async () => {
        while (!abortController.signal.aborted) {
          const { value, done } = await reader.read()
          if (done) break
          if (!value) continue

          lineBufferRef.current += decoder.decode(value, { stream: true })
          const lines = lineBufferRef.current.split(/\r?\n/)
          lineBufferRef.current = lines.pop() ?? ''

          for (const line of lines) {
            const parsed = parseSerialLine(line)
            if (parsed) {
              setAngles(parsed)
              setSampleCount((count) => count + 1)
              
              // Add to serial output display
              setSerialOutput((prev) => {
                const newOutput = prev + line + '\n'
                return newOutput.slice(-1000) // Keep last 1000 chars
              })
              
              // Record if recording is active
              if (isRecording && recordingRef.current) {
                recordingRef.current.data.push(parsed)
              }
            }
          }
        }
      })().catch(() => {
        setStatus('Serial stream ended')
        setConnected(false)
      })
    } catch (error) {
      setStatus(error instanceof Error ? error.message : 'Serial connection failed')
      setConnected(false)
    }
  }, [disconnectSerial])

  const setSimulatedAngles = useCallback((_pitch, roll) => {
    setMode('simulate')
    setAutoSimulate(false)
    setAngles({ pitch: 0, roll })
    setSampleCount((count) => count + 1)
    setStatus('Manual simulation')
  }, [])

  const enableAutoSimulation = useCallback(() => {
    setMode('simulate')
    setAutoSimulate(true)
    setStatus('Idle motion active')
  }, [])

  const selectSimulateMode = useCallback(() => {
    setMode('simulate')
    setAutoSimulate(false)
    setIsPlaying(false)
    setStatus('Manual simulation — use sliders')
  }, [])

  const stopRecording = useCallback(() => {
    setIsRecording(false)
    if (recordingTimeoutRef.current) {
      window.clearTimeout(recordingTimeoutRef.current)
      recordingTimeoutRef.current = null
    }
    const recording = recordingRef.current
    if (recording && recording.data && recording.data.length > 0) {
      if (recording.type === 'arm') {
        setRecordedArm(recording.data)
        setStatus('Arm movement saved')
      } else if (recording.type === 'leg') {
        setRecordedLeg(recording.data)
        setStatus('Leg movement saved')
      }
    } else {
      setStatus('Recording stopped — no data')
    }
    recordingRef.current = []
  }, [])

  const startRecording = useCallback((type) => {
    setIsRecording(true)
    recordingRef.current = { type: type, data: [] }
    setStatus(`Recording ${type}...`)
    
    // Auto-stop after specified duration
    recordingTimeoutRef.current = window.setTimeout(() => {
      stopRecording()
    }, recordingDuration * 1000)
  }, [recordingDuration, stopRecording])

  const playRecording = useCallback(() => {
    const recording = recordedArm || recordedLeg
    if (!recording || recording.length === 0) {
      setStatus('No recording to play')
      return
    }
    
    setIsPlaying(true)
    setPlaybackFrame(0)
    setMode('playback')
    setStatus('Playing recording...')
    
    playbackIntervalRef.current = window.setInterval(() => {
      setPlaybackFrame((frame) => {
        const nextFrame = frame + 1
        if (nextFrame >= recording.length) {
          return 0 // Loop
        }
        return nextFrame
      })
    }, 50) // 20Hz playback
  }, [recordedArm, recordedLeg])

  const stopPlayback = useCallback(() => {
    setIsPlaying(false)
    setIsPlayingTogether(false)
    setPlaybackFrame(0)
    if (playbackIntervalRef.current) {
      window.clearInterval(playbackIntervalRef.current)
      playbackIntervalRef.current = null
    }
    setMode('simulate')
    setStatus('Playback stopped')
  }, [])

  const playTogether = useCallback(() => {
    if (!recordedArm || !recordedLeg) {
      setStatus('Need both arm and leg recordings to play together')
      return
    }
    
    setIsPlaying(true)
    setIsPlayingTogether(true)
    setPlaybackFrame(0)
    setMode('playback')
    setStatus('Playing arm and leg together...')
    
    const maxLength = Math.max(recordedArm.length, recordedLeg.length)
    
    playbackIntervalRef.current = window.setInterval(() => {
      setPlaybackFrame((frame) => {
        const nextFrame = frame + 1
        if (nextFrame >= maxLength) {
          return 0 // Loop
        }
        return nextFrame
      })
    }, 50) // 20Hz playback
  }, [recordedArm, recordedLeg])

  useEffect(() => {
    if (mode !== 'simulate' || !autoSimulate) return undefined

    let frame = 0
    const id = window.setInterval(() => {
      frame += 1
      // Pitch locked to 0 — only roll drives motion
      const roll = Math.sin(frame * 0.04) * 14
      setAngles({ pitch: 0, roll })
      setSampleCount((count) => count + 1)
    }, 50)

    return () => window.clearInterval(id)
  }, [mode, autoSimulate])

  // Playback mode effect
  useEffect(() => {
    if (mode !== 'playback' || !isPlaying) return undefined

    const recording = recordedArm || recordedLeg
    if (!recording || recording.length === 0) return undefined

    // If playing together, use separate arm and leg angles
    if (isPlayingTogether && recordedArm && recordedLeg) {
      const armFrame = recordedArm[playbackFrame] || recordedArm[0]
      const legFrame = recordedLeg[playbackFrame] || recordedLeg[0]
      // Set angles to arm frame (leg frame will be passed separately via container)
      setAngles(armFrame)
    } else {
      setAngles(recording[playbackFrame])
    }
    setSampleCount((count) => count + 1)

    return undefined
  }, [mode, isPlaying, isPlayingTogether, playbackFrame, recordedArm, recordedLeg])

  useEffect(() => () => {
    disconnectSerial()
  }, [disconnectSerial])

  return {
    mode,
    angles,
    connected,
    status,
    sampleCount,
    autoSimulate,
    serialOutput,
    isRecording,
    recordedArm,
    recordedLeg,
    isPlaying,
    isPlayingTogether,
    playbackFrame,
    recordingDuration,
    previewMode,
    setMode,
    setSimulatedAngles,
    selectSimulateMode,
    enableAutoSimulation,
    connectSerial,
    disconnectSerial,
    startRecording,
    stopRecording,
    playRecording,
    playTogether,
    stopPlayback,
    setRecordingDuration,
    setPreviewMode,
  }
}
