#include <Wire.h>

// MPU6050 I2C address
const int MPU6050_ADDR = 0x68;

// I2C pins for ESP32
const int SDA_PIN = 21;
const int SCL_PIN = 22;

// Sensor variables
float accelX, accelY, accelZ;
float gyroX, gyroY, gyroZ;
float pitch = 0.0;
float roll = 0.0;

// Timing
unsigned long lastTime = 0;
const int SAMPLE_RATE = 50; // ms between samples (20Hz)

void setup() {
  Serial.begin(115200);
  
  // Initialize I2C with specified pins
  Wire.begin(SDA_PIN, SCL_PIN);
  
  // Initialize MPU6050
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x6B);  // PWR_MGMT_1 register
  Wire.write(0);     // Set to 0 to wake up MPU6050
  Wire.endTransmission(true);
  
  // Configure accelerometer (+-2g)
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x1C);  // ACCEL_CONFIG register
  Wire.write(0x00);  // +-2g
  Wire.endTransmission(true);
  
  // Configure gyroscope (+-250deg/s)
  Wire.beginTransmission(MPU6050_ADDR);
  Wire.write(0x1B);  // GYRO_CONFIG register
  Wire.write(0x00);  // +-250deg/s
  Wire.endTransmission(true);
  
  lastTime = millis();
}

void loop() {
  unsigned long currentTime = millis();
  
  if (currentTime - lastTime >= SAMPLE_RATE) {
    lastTime = currentTime;
    
    // Read accelerometer data
    Wire.beginTransmission(MPU6050_ADDR);
    Wire.write(0x3B);  // ACCEL_XOUT_H register
    Wire.endTransmission(false);
    Wire.requestFrom(MPU6050_ADDR, 6, true);
    
    int16_t accelX_raw = (Wire.read() << 8 | Wire.read());
    int16_t accelY_raw = (Wire.read() << 8 | Wire.read());
    int16_t accelZ_raw = (Wire.read() << 8 | Wire.read());
    
    // Convert to g-force (assuming +-2g range)
    accelX = accelX_raw / 16384.0;
    accelY = accelY_raw / 16384.0;
    accelZ = accelZ_raw / 16384.0;
    
    // Calculate pitch and roll from accelerometer
    // Pitch: rotation around X-axis
    // Roll: rotation around Y-axis
    pitch = atan2(accelY, sqrt(accelX * accelX + accelZ * accelZ)) * 180.0 / PI;
    roll = atan2(-accelX, sqrt(accelY * accelY + accelZ * accelZ)) * 180.0 / PI;
    
    // Send data as JSON for the website to parse
    Serial.print("{\"pitch\":");
    Serial.print(pitch, 2);
    Serial.print(",\"roll\":");
    Serial.print(roll, 2);
    Serial.println("}");
  }
}